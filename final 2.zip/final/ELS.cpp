/*IMPLEMENTATION OF
PAPERS: Listing All Maximal Cliques in Sparse Graphs in Near-optimal Time
AUTHORS: David Eppstein, Maarten Loffler, and Darren Strash  
*/




#include <iostream>
#include <vector>
#include <sstream>
#include <fstream>
#include <chrono>
#include <queue>
#include <unordered_set>
#include <algorithm>


using namespace std;

class Graph{


public:


    int V;
    vector<unordered_set<int>> adj;

    vector<int> clique_sizes; 
    Graph(){
    V = 0;

    adj.clear();
    }


    void addEdge(int u, int v){
        int max_node = max(u,v);
        if (max_node >= V) {
            V =max_node + 1;
            adj.resize(V);
        }

        adj[v].insert(u); 
        adj[u].insert(v);
       

    }


    void loadGraph(const string  &filename){
        ifstream file(filename);
        if (!file){
            cerr << "Error in opening the given file: " << filename << endl;
            return;
        }


        string line;
        int max_node_id = -1;
        
        while (getline(file,line)) {
            if (line[0] == '#' || line.empty()) {
                continue; 
            }    
            istringstream iss(line);
            int u,v;
            if (iss >> u >> v) {
                max_node_id = max(max_node_id,max(u,v));
            }


        }
        
        if (max_node_id < 0) {
            cerr << "No valid edges are in file" << endl;
            return;
        }
        
        V = max_node_id + 1;
        adj.resize(V);
        
        file.clear();
        file.seekg(0);
        

        while (getline(file,line)) {
            if (line[0] == '#' || line.empty()) {
            continue;
            }
            
            istringstream iss(line);
            int u, v;
            if (iss >> u >> v) {
                addEdge(u, v);
            }



        }
        cout << "Graph loaded with " << V << " nodes and ";
        file.close();
       
        
        size_t edge_count = 0;
        for (int i = 0;i < V; i++) {
            edge_count += adj[i].size();
        }

        cout << (edge_count / 2) << " edges." << endl;
    }




    vector<int> getDegeneracyOrder() {

        vector<int> order;

        vector<int> degree(V);

        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> minHeap;

        for (int i = 0;i < V;i++) {
            degree[i] = adj[i].size();
            minHeap.push({degree[i],i});
        }

        vector<bool> removed(V, false);
        while (!minHeap.empty()) {
            auto x= minHeap.top();
            int deg = x.first;
            int v= x.second;
            minHeap.pop();
            
            if (removed[v]) {
                continue;
            }

            order.push_back(v);

            removed[v] = true;
            for (int neighbor: adj[v]){
                if (!removed[neighbor]){
                degree[neighbor]--;
                minHeap.push({degree[neighbor],neighbor});
                }
            }
        }
        return order;
    }

    void BronKerboschPivot(unordered_set<int>& P, unordered_set<int>& R, unordered_set<int>& X) {
        if (P.empty() && X.empty()){
            clique_sizes.push_back(R.size()); 
            return;
        }

        int pivot = -1;
        int max_connections = -1;
        
        for (int u: P){
            int connections = 0;
            for (int v: P) {
                if (adj[u].find(v) != adj[u].end()) {
                    connections++;
                }
            }


            if (connections > max_connections) {

                max_connections = connections;
                pivot = u;
            }
        }
        
        for (int u: X) {
            int connections = 0;
            for (int v: P) {
                if (adj[u].find(v) != adj[u].end()) {
                    connections++;
                }
            }
            if (connections > max_connections) {
                max_connections = connections;
                pivot= u;
            }
        }

        
        unordered_set<int> P_copy = P;
        
        for (int v: P_copy) {
            if (pivot!= -1 && adj[pivot].find(v)!= adj[pivot].end()) {
                continue;
            }
            
            unordered_set<int> newP, newX;
            unordered_set<int> newR = R;
            newR.insert(v);

            for (int u: P) {
                if (adj[v].find(u)!= adj[u].end()) {
                      newP.insert(u);
                }
            }
            
            for (int u: X) {
                if (adj[v].find(u)!= adj[v].end()) {
                      newX.insert(u);
                }
            }

            BronKerboschPivot(newP, newR, newX);
            
            P.erase(v);
            X.insert(v);
        }
    }

    void BronKerboschDegeneracy() {

    vector<int> order = getDegeneracyOrder();

        unordered_set<int> visited;

        for (int vi: order) {
            unordered_set<int> P,X;
            
            for (int neighbor: adj[vi]) {
                if (visited.find(neighbor) == visited.end()) {
                     P.insert(neighbor);
                } else {
                     X.insert(neighbor);
                }
            }
            
            unordered_set<int> R = {vi};

            BronKerboschPivot(P,R,X);
            visited.insert(vi);
        }

        
        cout<< "Found " << clique_sizes.size() << " maximal cliques." << endl;
    }

    void saveCliqueData(const string &filename) {
        ofstream file(filename);
        if (!file) {
            cerr << "Error in opening output file: " << filename << endl;
            return;
        }
        
        for (int size: clique_sizes) {
        file <<size << "\n";


        }
        file.close();

        cout<< "Clique sizes saved to file: " << filename << endl;
    }
};

int main() {
    auto start_time = chrono::high_resolution_clock::now();

    Graph g;
    g.loadGraph("Wiki-Vote-0-based.txt");  //insert the string of the dataset file name you want to implement this algorithm on


    g.BronKerboschDegeneracy();  


    g.saveCliqueData("clique_sizes_Wiki-Vote_final.txt"); //insert the filename you want clique sizes to be saved into

    auto end_time = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::milliseconds>(end_time-start_time).count();

    cout << "Execution time taken for ELS algorithm: " << duration / 1000.0 << " seconds" << endl;

    return 0;
}