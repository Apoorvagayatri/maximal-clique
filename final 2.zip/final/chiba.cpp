/*IMPLEMENTATION OF
THE PAPER: ARBORICITY AND SUBGRAPH LISTING ALGORITHMS
AUTHORS:  NORISHIGE CHIBA AND TAKAO NISHIZEKVI
*/




#include <iostream>
#include <fstream>
#include <sstream>
#include <climits>
#include <string>
#include <chrono>
#include <queue>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <map>

using namespace std;


vector<unordered_set<int>> G;

vector<int> d;

int n;

int maxCliqueSize = 0;

int maximalCliqueCount = 0;

vector<int> cliqueSizes; 



inline void addEdge(int u,int v) {
    G[v].insert(u);
    d[v]++;
    G[u].insert(v);
    d[u]++;
   
}

void loadGraph(const string &filename) {


    ifstream file(filename);
    if (!file) {
        cerr << "Error while opening file: " << filename << endl;
        return;
    }


      string line;

    int max_node_id = -1;
    
     while (getline(file,line)) {
        if (line.empty() || line[0] == '#') {
        continue;
        }
        
        istringstream iss(line);

        int u,v;

        if (iss >> u >> v) {
            max_node_id = max(max_node_id,max(u,v));

        }
    }
    
    if (max_node_id < 0) {
        cerr << "No valid edges were found in the file" << endl;

        return;
    }
    
    n = max_node_id +1;
    G.resize(n);
    d.resize(n, 0);
    
    file.clear();

    file.seekg(0);
    
    int edge_count = 0;
    while (getline(file, line)) {
        if (line.empty() || line[0] == '#'){
        continue;
        }
        istringstream iss(line);
        int u,v;
        if (iss >> u >> v && u != v) {  
            addEdge(u,v);
            edge_count++;
        }
    }
    
    cout << "Graph loaded with " << n << " nodes and " << edge_count << " edges" << endl;

}

bool isMaximal(const vector<int>& clique) {
    if (clique.empty()) return false;
    
    if (clique.size() == 1) return G[clique[0]].empty();
    
    int minSize = INT_MAX;
    int minIndex = 0;
    
    for (size_t i = 0;i < clique.size();i++) {
        int size = G[clique[i]].size();
        if (size < minSize) {
            minSize = size;
            minIndex = i;
        }
    }
    
    unordered_set<int> commonNeighbors(G[clique[minIndex]]);
    
    for (size_t i = 0;i < clique.size();i++) {
        if (i!=minIndex) {
            for (auto it = commonNeighbors.begin();it != commonNeighbors.end();) {

                if (G[clique[i]].find(*it) == G[clique[i]].end()) {
                    it =commonNeighbors.erase(it);

                } else {
                    ++it;
                }
            }
        }
    }

    
    for (int v: clique) {
        commonNeighbors.erase(v);
    }
    
    return commonNeighbors.empty();
}

void reportMaximalClique(const vector<int>& clique) {
    if (!isMaximal(clique)) return;
    
    maximalCliqueCount++;

    cliqueSizes.push_back(clique.size());


    if (maximalCliqueCount % 1000 == 0) {
        cout << "Found " << maximalCliqueCount << " maximal cliques" << endl;
    }



}

vector<int> intersect(const vector<int>& a, const unordered_set<int>& b) {
    vector<int> result;
    result.reserve(min(a.size(), b.size())); 
    
    for (int v: a) {
        if (b.find(v) != b.end()) {
            result.push_back(v);
        }
    }


    return result;
}

void chibaMaximalCliques(vector<int>& P, vector<int>& R, int depth = 0) {
    if (P.empty()) {
        if (!R.empty()) {
            reportMaximalClique(R);
        }
        return;
    }
    
    while (!P.empty()) {
        int max_degree = -1;

        int max_index = -1;
        
        for (size_t i = 0; i < P.size(); i++) {
            int degree = d[P[i]];
            if (degree > max_degree) {
                max_degree = degree;

                max_index = i;
            }
        }
        
        int v = P[max_index];
        P[max_index] = P.back();

        P.pop_back();
        
        R.push_back(v);
        
        vector<int> P_new = intersect(P,G[v]);
        
        chibaMaximalCliques(P_new,R,depth + 1);
        
        R.pop_back();
    }
}

vector<int> degeneracyOrder() {
    vector<int> order;

    order.reserve(n);
    
    vector<int> degrees = d;

    vector<bool> removed(n, false);
    

    vector<vector<int>> buckets(n);
    for (int v = 0;v < n;v++) {
        buckets[degrees[v]].push_back(v);
    }

    
    int current_degree = 0;
    

    for (int i = 0;i < n;i++) {
        while (current_degree < n && buckets[current_degree].empty()) {
            current_degree++;
        }
        
        if (current_degree == n) {
             break;
        }
        
        int v = buckets[current_degree].back();
        buckets[current_degree].pop_back();
        
        order.push_back(v);
        removed[v] =true;
        
        for (int u: G[v]) {
            if (!removed[u]) {
                 auto& bucket = buckets[degrees[u]];

                bucket.erase(find(bucket.begin(), bucket.end(), u));
                
                degrees[u]--;
                buckets[degrees[u]].push_back(u);
                
                current_degree = min(current_degree, degrees[u]);
            }
        }
    }
    
    return order;
}

void findMaximalCliques() {
    vector<int> order = degeneracyOrder();
    


    
    for (int i = 0; i < order.size(); i++) {
        int v = order[i];
        
        if (d[v] == 0) continue;
        
        vector<int> neighbors;
        for (int u: G[v]) {
            if (find(order.begin() + i + 1, order.end(), u) != order.end()) {
                neighbors.push_back(u);
            }
        }


        
        if (!neighbors.empty()) {
            vector<int> R = {v};
            chibaMaximalCliques(neighbors, R);

        } else {
            vector<int> singleton = {v};

            reportMaximalClique(singleton);
        }
        
       
    }
}

void saveCliqueSizesToFile(const string& filename) {
    ofstream file(filename);

    if (!file.is_open()){
        cerr << "Error opening file for writing: " << filename << endl;
        return;
    }


    
    file << "Clique Size,Count" << endl;
    
    map<int, int> sizeFrequency;
    for (int size: cliqueSizes) {
        sizeFrequency[size]++;
    }
    
    for (const auto& pair: sizeFrequency) {
        file << pair.first << "," << pair.second << endl;
    }
    
    cout << "Saved " << cliqueSizes.size() << " clique sizes to " << filename << endl;
    
    cout << "Found " << sizeFrequency.size() << " different clique sizes" << endl;
    
    file.close();

}

int main(){

    string input_file="wiki-Vote.txt"; //set the string of the dataset file name you want to implement this algorithm on
    
    loadGraph(input_file);
    
    auto start = chrono::high_resolution_clock::now();

    findMaximalCliques();

    auto end = chrono::high_resolution_clock::now();

    chrono::duration<double> elapsed = end-start;
    
    cout << "Number of maximal cliques found: " << maximalCliqueCount << endl;
    cout << "Execution time for chiba implementation : " << elapsed.count() << " seconds" << endl;
    

    string outputFile = "clique_sizes_wiki-Vote.csv"; //set the filename you want clique sizes to be saved into


    saveCliqueSizesToFile(outputFile);
    
    return 0;
}