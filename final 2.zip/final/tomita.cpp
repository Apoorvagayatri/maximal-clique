/*IMPLEMENTATION OF
PAPER: The worst-case time complexity for generating all maximal cliques and computational experiments
AUTHORS:Etsuji Tomitaa,∗, Akira Tanakaa,b, Haruhisa Takahashia */




#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <utility>
#include <fstream>
#include <sstream>
#include <chrono>
#include <algorithm>
#include <unordered_set>
#include <map>

using namespace std;
using namespace std::chrono;

vector<int> cliqueSizes;

int maximalcount = 0;

class Graph {
private:

    int V;
    int E;
    vector<vector<int>> adjList;
    vector<unordered_set<int>> adjSet; 


public:
    Graph(int verticesCount) : V(verticesCount), E(0), adjList(verticesCount), adjSet(verticesCount) {}

    void addEdge(int u,int v) {

        adjList[v].push_back(u);
        adjSet[u].insert(v);
        adjList[u].push_back(v);
        adjSet[v].insert(u);
        E++;

    }

    const vector<int>& getNeighbors(int v) const {
        return adjList[v];
    }


    bool isNeighbor(int u,int v) const {
        return adjSet[u].find(v) != adjSet[u].end();
    }

    int getVertexCount() const {
        return V;
    }


};

void expand(vector<int>& Q, vector<int>& SUBG, vector<int>& CAND, const Graph& G) {
    if (SUBG.empty()) {
        maximalcount++;

        cliqueSizes.push_back(Q.size());
        return;
    }



    int u = SUBG[0];
    int max_size = 0;
    
    for (int vertex: SUBG) {
        int count = 0;
        for (int candidate: CAND) {
            if (G.isNeighbor(vertex,candidate)) {
                count++;
            }
        }
        if (count > max_size) {
            max_size = count;
            u = vertex;
        }
    }



    vector<int> ext_u;

    for (int q: CAND) {
        if (!G.isNeighbor(u,q)) {
            ext_u.push_back(q);
        }
    }


    for (int q: ext_u) {
        Q.push_back(q);
        
        vector<int> SUBG_q,CAND_q;
        
        for (int v: SUBG) {
            if (G.isNeighbor(q,v)) {
                SUBG_q.push_back(v);
            }
        }
        
        for (int v: CAND) {
            if (G.isNeighbor(q,v)) {
                CAND_q.push_back(v);
            }
        }
        
        expand(Q,SUBG_q,CAND_q,G);
        
        Q.pop_back();



        
        auto it = find(CAND.begin(), CAND.end(), q);
        if (it != CAND.end()) {
            *it = CAND.back();
            CAND.pop_back();
        }
    }
}

void cliques(const Graph& G) {
    vector<int> Q;

    vector<int> SUBG, CAND;
    
    for (int i = 0;i < G.getVertexCount();i++) {
        SUBG.push_back(i);
        CAND.push_back(i);
    }



    
    expand(Q,SUBG,CAND,G);
}

Graph loadGraph(const string& filename) {
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;

        exit(1);
    }

    map<int, int> nodeMapping;

    vector<pair<int, int>> edges;
    int src, dst;

    int nodeCount = 0;
    int lineCount = 0;

    string line;

    while (getline(file, line) && line[0] == '#') {
        lineCount++;
    }

    
    do {
        if (line.empty()) continue;
        
        istringstream iss(line);
        if (iss >> src >> dst) {
            lineCount++;


            if (nodeMapping.find(src) == nodeMapping.end()) {
                nodeMapping[src] = nodeCount++;
            }
            if (nodeMapping.find(dst) == nodeMapping.end()) {
                nodeMapping[dst] = nodeCount++;
            }
            edges.push_back({nodeMapping[src], nodeMapping[dst]});
        }
    } while (getline(file, line));
    
    cout << "Total unique nodes: " << nodeCount << endl;


    cout << "Total edges: " << edges.size() << endl;

    Graph g(nodeCount);
    
    for (const auto& edge : edges) {
        g.addEdge(edge.first, edge.second);
    }
    
    cout << "Graph construction completed." << endl;
    
    return g;
}

void saveCliqueSizesToFile(const string& filename) {

    ofstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file for writing: " << filename << endl;
        return;
    }
    
    
    file << "Clique Size,Count" << endl;


    
    map<int, int> sizeFrequency;
    for (int size : cliqueSizes) {
        sizeFrequency[size]++;
    }


    
    for (const auto& pair : sizeFrequency) {
        file << pair.first << "," << pair.second << endl;
    }

    
    cout << "Saved " << cliqueSizes.size() << " clique sizes to " << filename << endl;
    cout << "Found " << sizeFrequency.size() << " different clique sizes" << endl;
    
    file.close();
}



int main() {
    string datasetPath = "/Users/apoorvagayatrik/final/Wiki-Vote.txt"; //set the string of the dataset file name you want to implement this algorithm on

    Graph g = loadGraph(datasetPath);
    auto start = high_resolution_clock::now();

    cliques(g);
    
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stop - start);
    cout << "The total number of maximal cliques are " << maximalcount;
    cout << "   Execution Time: " << duration.count() << " ms" << endl;

    string outputFile = "clique_sizes_as-skitter.csv"; //set the filename you want clique sizes to be saved into

    saveCliqueSizesToFile(outputFile);

    return 0;
}