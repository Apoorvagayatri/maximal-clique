# Maximal Clique Enumeration Algorithms

Webpage link: https://apoorvagayatri.github.io/temp-maximal-clique/

## Group Members
- Apoorva Gayatri K 2022A7PS0232H
- Anika Rudraraju  2022A7PS2011H
- Nikitha Kolli 2022A7PS0207H
- Navya Ennam 2022A7PS0001H
- Manvitha G 2022A7PS0225H

### Individual Contributions
- Tomita: Apoorva
- ELS: Nikitha, Navya
- Chiba: Anika, Manvitha

## Datasets Tested
1. **Email-Enron**: Email communication network from Enron
2. **Wiki-Vote**: Wikipedia voting network (preprocessed with 0-based indexing for ELS code)
3. **as-skitter**: Internet topology graph from traceroutes

## Execution Instructions

### Prerequisites
- C++ compiler with C++11 support
- Input graph files in edge list format 

### Compilation
```bash
g++ -std=c++17 -O3 -o clique_finder main.cpp
```
To change the input dataset, change the line 'string input_file="DATASET_FILE_NAME.txt"' and 'string output_file="CLIQUE_SIZES_FILE_NAME.txt"' inside the main function.

### Execution
```bash
./clique_finder
```

### Input Format
The program expects input files in edge list format (one edge per line):
```
source_node target_node
```
Comments are indicated by lines starting with '#'.

### Output
The program generates a text file containing the sizes of all maximal cliques found, which can be used for further analysis or visualization.

## Experimental Results

### Email-Enron Dataset
- Total Maximal Cliques: 226,859
- Largest Clique Size: 20
- Smallest Clique Size: 2
- Average Clique Size: 8.08
- Standard Deviation: 3.32

### Wiki-Vote Dataset
- Total Maximal Cliques: 459,002
- Largest Clique Size: 17
- Smallest Clique Size: 2
- Average Clique Size: 7.32
- Standard Deviation: 2.35

### as-skitter Dataset
- Total Maximal Cliques: 37,322,355
- Largest Clique Size: 67
- Smallest Clique Size: 2
- Average Clique Size: 19.94
- Standard Deviation: 12.91

#### Analysis Time
##### ELS
Email-Enron Dataset: 9.719 seconds
Wiki-Vote Dataset: 12.119 seconds
as-skitter Dataset: 2261.92 seconds (approximately 37.7 minutes)

##### Tomita
Email-Enron Dataset: 294.561 seconds
Wiki-Vote Dataset: 11.012 seconds
as-skitter Dataset: 45h 18m 39s

##### Chiba
Email-Enron Dataset: 30577 seconds
Wiki-Vote Dataset: 1796 seconds
as-skitter Dataset: >72 hours

## References
1. Tomita, E., Tanaka, A., & Takahashi, H. (2006). The worst-case time complexity for generating all maximal cliques and computational experiments.
2. Eppstein, D., Löffler, M., & Strash, D. (2010). Listing All Maximal Cliques in Sparse Graphs in Near-Optimal Time. Algorithms and Computation, 403-414.
3. Eppstein, D., & Strash, D. (2011). Arboricity and Subgraph Listing Algorithms.